using System;
using System.IO;
using System.Text;


class MainClass {
  public static void Main (string[] args) {

    StreamWriter cachorro = new StreamWriter("cachorro.txt",true,Encoding.UTF8);
    string str = string.Empty;

    while(str != "sair"){
      str = Console.ReadLine();
      
      if(str != "sair") 
      cachorro.WriteLine(str);
      
    }
    cachorro.Close();
    
    StreamReader leitura = new StreamReader("cachorro.txt");
    
    while(!leitura.EndOfStream){
      string ler = leitura.ReadLine();

      Console.WriteLine(ler);
    }
    leitura.Close();
  }
}